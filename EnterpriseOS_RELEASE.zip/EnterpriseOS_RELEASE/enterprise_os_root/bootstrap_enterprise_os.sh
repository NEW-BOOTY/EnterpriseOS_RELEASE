#!/usr/bin/env bash
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#

set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${ROOT_DIR}/.venv"
LOG_DIR="${ROOT_DIR}/logs"
mkdir -p "${LOG_DIR}"

LOG_FILE="${LOG_DIR}/enterprise_os_bootstrap_$(date -u +%Y%m%dT%H%M%SZ).log"

log() {
  local level="$1"; shift
  local msg="$*"
  printf '{"ts":"%s","level":"%s","msg":"%s"}\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "${level}" "${msg}" | tee -a "${LOG_FILE}"
}

die() {
  log "ERROR" "$*"
  exit 1
}

trap 'die "bootstrap_failed line=${LINENO}"' ERR

log "INFO" "ENTERPRISE-OS bootstrap starting at ROOT_DIR=${ROOT_DIR}"

# ------------------ Check venv ------------------

if [[ ! -d "${VENV_DIR}" ]]; then
  die "Python virtual environment not found at ${VENV_DIR}. Ensure Archive.zip was unpacked correctly."
fi

# shellcheck source=/dev/null
if ! source "${VENV_DIR}/bin/activate"; then
  die "Failed to activate virtualenv at ${VENV_DIR}"
fi

log "INFO" "Virtualenv activated"

# ------------------ Dependency Sanity Checks ------------------

command -v python >/dev/null 2>&1 || die "python not found in PATH"
command -v uvicorn >/dev/null 2>&1 || die "uvicorn not found in virtualenv. Check that requirements are installed."

log "INFO" "Python and uvicorn detected"

# ------------------ Start Control Plane ------------------

export ENTERPRISE_OS_HOST="${ENTERPRISE_OS_HOST:-0.0.0.0}"
export ENTERPRISE_OS_PORT="${ENTERPRISE_OS_PORT:-8080}"

log "INFO" "Starting ENTERPRISE-OS control plane on ${ENTERPRISE_OS_HOST}:${ENTERPRISE_OS_PORT}"

cd "${ROOT_DIR}" || die "Cannot cd into ROOT_DIR=${ROOT_DIR}"

# Use exec so signals propagate properly
exec uvicorn app.main:app \
  --host "${ENTERPRISE_OS_HOST}" \
  --port "${ENTERPRISE_OS_PORT}" \
  >> "${LOG_FILE}" 2>&1

#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#
