# IBM Outreach

- DevRel: developer.ibm.com  
- Partnerships: ibm.com/partners  
- CTO: IBM exec LinkedIn  