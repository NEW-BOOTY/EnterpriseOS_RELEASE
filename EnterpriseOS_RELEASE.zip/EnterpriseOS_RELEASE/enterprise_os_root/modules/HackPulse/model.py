Python ML Training Script
