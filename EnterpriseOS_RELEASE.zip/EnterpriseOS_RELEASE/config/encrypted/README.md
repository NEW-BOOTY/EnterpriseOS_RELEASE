# Encrypted Configuration Store

Use this directory only for encrypted secrets or metadata.
