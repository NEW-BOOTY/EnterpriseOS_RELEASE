/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# Security Policy

## Supported Versions

The demo reference implementation is versioned as `0.1.0-demo`. Security
fixes are applied on a best-effort basis while the project is under active
development.

## Reporting Vulnerabilities

If you discover a security issue, please report it privately:

- Email: PAPER.IN.MY.POCKET@MY.COM
- Subject line: `[SECURITY] Enterprise-OS vulnerability`

Please include:

- A detailed description of the vulnerability.
- Steps to reproduce.
- Any relevant logs or PoC code.

You will receive an acknowledgment within 3 business days.

## Coordinated Disclosure

Please do not publicly disclose vulnerabilities until:

- A fix has been developed and released, or
- You have received explicit written permission.

## Dependency Management

- Dependencies are pinned via `requirements.txt`.
- SBOMs are generated using `scripts/generate_sbom.sh`.
- Dependency updates are reviewed for breaking changes and license impact.

## Secrets

No hardcoded secrets are stored in this repository. All credentials are
provided via:

- Environment variables,
- Kubernetes Secrets, or
- `.env` files that are **never** committed to version control.

/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
