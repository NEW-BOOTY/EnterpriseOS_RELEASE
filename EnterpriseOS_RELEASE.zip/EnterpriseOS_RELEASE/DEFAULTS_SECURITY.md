# SECURITY DEFAULTS

- DEBUG must be disabled in production.
- Never use default credentials.
- Minimize external network exposure.
- Avoid logging sensitive information.
