# Enterprise OS v3.0.0-SAFE – Usage (SAFE MODE)

## Run Everything

```bash
chmod +x Enterprise-OS-v3.0.sh
./Enterprise-OS-v3.0.sh --run-everything
```

This will:
- Detect OS and package manager
- Initialize project directories for all frameworks
- Attempt to install local audit tools (trivy, syft, gitleaks)
- Perform local SBOM/MBOM/secrets/config checks (if tools are available)
- Bootstrap v2.0 architecture (job runner + plugin marketplace + node-graph orchestrator)
- Emit GUI source and attempt to start FastAPI dashboard
- Emit daemon templates (but NOT install them)
- Emit .pkg skeleton (on macOS) without running pkgbuild
