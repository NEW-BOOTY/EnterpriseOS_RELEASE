/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
fn main() {
    println!("Hello LambdaLoom");
}
