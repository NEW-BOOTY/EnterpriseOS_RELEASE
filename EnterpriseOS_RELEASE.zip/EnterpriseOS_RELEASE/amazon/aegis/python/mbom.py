print('{"bomFormat":"CycloneDX","components":[{"name":"aegis","version":"1.0","type":"application"}]}')
