# EXPORT CONTROL NOTICE

This software may be subject to export control laws and regulations.
Licensees are responsible for ensuring compliance with applicable rules.
