# ARCHITECTURE

High-level overview of Enterprise-OS™ components, provider modules, and shared services.

```text
+----------------------------- Control Plane -----------------------------+
|  CLI / Meta-Builder  |  Policies  |  Logging & Telemetry  |  CI/CD     |
+-----------------------------------------------------------------------+
|          Provider Modules (Apple/AWS/Google/Azure/Oracle/IBM/Meta)     |
+------------------------------------------------------------------------+
```
