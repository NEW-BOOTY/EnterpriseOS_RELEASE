/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# Enterprise-OS™ End-User License Agreement (EULA)

> This EULA governs commercial use of Enterprise-OS™ by Devin B. Royal
> (“Licensor”) and you (“Licensee”). By installing or using Enterprise-OS™,
> you agree to be bound by this EULA.

## 1. Grant of License

Licensor grants Licensee a non-exclusive, non-transferable license to install
and use Enterprise-OS™ for internal business purposes, on the number of
environments, nodes, or users specified in the applicable order form or SOW.

## 2. Ownership

Enterprise-OS™ is licensed, not sold. All intellectual property rights,
including all copyrights, trade secrets, trademarks, and derivative works,
remain the exclusive property of Devin B. Royal.

## 3. Restrictions

Licensee shall not:

- Reverse engineer, decompile, or disassemble Enterprise-OS™, except to the
  extent explicitly allowed by applicable law.
- Resell, sublicense, rent, lease, or provide Enterprise-OS™ as a service to
  third parties without a separate written agreement.
- Remove or alter any copyright, trademark, or proprietary notices.

## 4. Open-Source Components

Certain components are provided under separate open-source licenses (e.g.,
Apache-2.0). Those licenses govern their respective components. See
`THIRD_PARTY_NOTICES.md`.

## 5. Confidentiality

Enterprise-OS™ and associated documentation are considered confidential and
proprietary. Licensee shall protect this information with the same degree of
care used to protect its own confidential information.

## 6. Support and Updates

Unless specified in a separate written agreement, Licensor is not obligated
to provide support, maintenance, or updates. Any such services may be offered
under separate terms.

## 7. Disclaimer of Warranty

ENTERPRISE-OS™ IS PROVIDED “AS IS” WITHOUT WARRANTY OF ANY KIND, WHETHER
EXPRESS, IMPLIED, OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.

## 8. Limitation of Liability

IN NO EVENT SHALL LICENSOR BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL,
CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS OR REVENUE,
ARISING OUT OF OR RELATED TO THE USE OF ENTERPRISE-OS™, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGES.

## 9. Term and Termination

This EULA remains in effect until terminated. Licensor may terminate this
EULA upon material breach by Licensee. Upon termination, Licensee must cease
all use of Enterprise-OS™ and destroy all copies.

## 10. Governing Law

This EULA shall be governed by and construed in accordance with the laws of
the State of Texas, without regard to its conflict-of-law rules.

## 11. Entire Agreement

This EULA, together with any order forms or SOWs, constitutes the entire
agreement between the parties regarding Enterprise-OS™.

/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
