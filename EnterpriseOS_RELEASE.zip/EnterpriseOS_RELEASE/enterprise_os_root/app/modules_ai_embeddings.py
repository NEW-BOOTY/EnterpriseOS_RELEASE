"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from sentence_transformers import SentenceTransformer, util

from .base_module import BaseModule
from .models import ModuleKind


class AIEmbeddingModule(BaseModule):
    _model: Optional[SentenceTransformer] = None

    def __init__(self) -> None:
        super().__init__(
            name="ai-embeddings",
            kind=ModuleKind.AI,
            description="Local CPU embedding demo using sentence-transformers; computes similarity between two texts.",
        )

    def _ensure_model(self) -> SentenceTransformer:
        if self._model is None:
            # Small, CPU-friendly model; weights downloaded at runtime.
            self._model = SentenceTransformer("all-MiniLM-L6-v2")
        return self._model

    async def trigger(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        text_a = payload.get("text_a")
        text_b = payload.get("text_b")
        if not text_a or not text_b:
            raise ValueError("Payload must contain 'text_a' and 'text_b' fields.")

        model = self._ensure_model()
        emb_a = model.encode(text_a, convert_to_tensor=True, normalize_embeddings=True)
        emb_b = model.encode(text_b, convert_to_tensor=True, normalize_embeddings=True)
        similarity = float(util.cos_sim(emb_a, emb_b).item())

        metrics = {"similarity": similarity, "embedding_dim": len(emb_a)}
        self._mark_success(metrics=metrics)
        return metrics

    async def health(self) -> Dict[str, Any]:
        try:
            model = self._ensure_model()
            _ = model.get_sentence_embedding_dimension()
            self._mark_success(metrics={"health": "ok"})
            return {"status": "ok"}
        except Exception as exc:  # noqa: BLE001
            self._mark_error(str(exc))
            return {"status": "error", "error": str(exc)}


"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""
