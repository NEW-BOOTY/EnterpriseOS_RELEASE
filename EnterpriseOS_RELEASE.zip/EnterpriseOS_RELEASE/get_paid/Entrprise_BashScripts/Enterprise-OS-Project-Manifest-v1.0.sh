#!/usr/bin/env bash
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
#
# Enterprise-OS-Project-Manifest-v1.0.sh
# Version: 1.0.0
#
# **PROJECT MANIFEST — FULL SPEC FOR EACH FRAMEWORK**
#
# This script emits a **complete, production-grade design document**
# for every `enterprise_os_projects/<name>` folder.
#
# **What you get**
#   • One-section per project
#   • Exact purpose, tech stack, API contract, security model
#   • Directory layout + example starter files (Java + Maven)
#   • Build / run / test instructions
#   • Integration points with the orchestrator, GUI, and cloud IAM
#
# **Run it once — it merges safely into your CUSTOM_ROOT**
#
# **NO OVERWRITE** — `rsync --ignore-existing`

set -euo pipefail

# ------------- CUSTOM ROOT -------------
CUSTOM_ROOT="/Volumes/Devin_Royal/CORPORATIONS/Corporations/Enterprise-Meta-Builder/Enterprise/enterprise_meta_builder_fixed/enterprise_v2"
[[ ! -d "${CUSTOM_ROOT}" ]] && { echo "ERROR: CUSTOM_ROOT not found"; exit 1; }

MANIFEST_DIR="${CUSTOM_ROOT}/enterprise_os_manifest"
mkdir -p "${MANIFEST_DIR}"

# ------------- Safe Merge -------------
safe_merge() {
  local src="$1" dest="$2"
  mkdir -p "${dest}"
  rsync -a --ignore-existing "${src}/" "${dest}/" 2>/dev/null || true
  echo "Merged manifest → ${dest}"
}

# ------------- Helper: Write File -------------
write_file() {
  local path="$1" content="$2"
  mkdir -p "$(dirname "${path}")"
  printf "%s\n" "${content}" > "${path}"
}

# ------------- Project: chimera (Google) -------------
emit_chimera() {
  local proj_dir="${CUSTOM_ROOT}/enterprise_os_projects/chimera"
  local tmp="/tmp/manifest_chimera_$$"
  mkdir -p "${tmp}/src/main/java/com/devinroyal/chimera" "${tmp}/src/test/java/com/devinroyal/chimera"

  # pom.xml
  cat > "${tmp}/pom.xml" <<'POM'
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                             http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.devinroyal</groupId>
  <artifactId>chimera</artifactId>
  <version>1.0.0</version>
  <properties>
    <maven.compiler.source>17</maven.compiler.source>
    <maven.compiler.target>17</maven.compiler.target>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
  </properties>
  <dependencies>
    <dependency>
      <groupId>com.google.cloud</groupId>
      <artifactId>google-cloud-pubsub</artifactId>
      <version>1.127.0</version>
    </dependency>
    <dependency>
      <groupId>io.jsonwebtoken</groupId>
      <artifactId>jjwt-api</artifactId>
      <version>0.11.5</version>
    </dependency>
    <dependency>
      <groupId>io.jsonwebtoken</groupId>
      <artifactId>jjwt-impl</artifactId>
      <version>0.11.5</version>
      <scope>runtime</scope>
    </dependency>
    <dependency>
      <groupId>io.jsonwebtoken</groupId>
      <artifactId>jjwt-jackson</artifactId>
      <version>0.11.5</version>
      <scope>runtime</scope>
    </dependency>
    <dependency>
      <groupId>org.junit.jupiter</groupId>
      <artifactId>junit-jupiter</artifactId>
      <version>5.10.0</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
  <build>
    <plugins>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-surefire-plugin</artifactId>
        <version>3.1.2</version>
      </plugin>
    </plugins>
  </build>
</project>
POM

  # Main App
  cat > "${tmp}/src/main/java/com/devinroyal/chimera/ChimeraService.java" <<'JAVA'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
package com.devinroyal.chimera;

import com.google.cloud.pubsub.v1.Publisher;
import com.google.pubsub.v1.PubsubMessage;
import com.google.pubsub.v1.TopicName;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.time.Instant;
import java.util.Base64;
import java.util.concurrent.TimeUnit;

public class ChimeraService {
    private static final String PROJECT_ID = System.getenv("GCP_PROJECT_ID");
    private static final String TOPIC_ID = "chimera-events";
    private static final String JWT_SECRET = System.getenv("CHIMERA_JWT_SECRET");

    public static void main(String[] args) throws Exception {
        if (PROJECT_ID == null || JWT_SECRET == null) {
            throw new IllegalStateException("GCP_PROJECT_ID and CHIMERA_JWT_SECRET required");
        }
        String jwt = generateJwt();
        System.out.println("Chimera JWT: " + jwt);

        Publisher publisher = Publisher.newBuilder(TopicName.of(PROJECT_ID, TOPIC_ID)).build();
        String payload = "{\"timestamp\":" + Instant.now().getEpochSecond() + ",\"jwt\":\"" + jwt + "\"}";
        PubsubMessage msg = PubsubMessage.newBuilder()
                .setData(com.google.protobuf.ByteString.copyFromUtf8(payload))
                .build();
        publisher.publish(msg).get(10, TimeUnit.SECONDS);
        System.out.println("Published event to Pub/Sub");
        publisher.shutdown();
    }

    private static String generateJwt() {
        return Jwts.builder()
                .setSubject("chimera-service")
                .setIssuedAt(java.util.Date.from(Instant.now()))
                .setExpiration(java.util.Date.from(Instant.now().plusSeconds(3600)))
                .signWith(SignatureAlgorithm.HS256, Base64.getDecoder().decode(JWT_SECRET))
                .compact();
    }
}
JAVA

  # Test
  cat > "${tmp}/src/test/java/com/devinroyal/chimera/ChimeraServiceTest.java" <<'JAVA'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
package com.devinroyal.chimera;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ChimeraServiceTest {
    @Test void jwtGenerationIsDeterministic() {
        System.setProperty("GCP_PROJECT_ID", "test");
        System.setProperty("CHIMERA_JWT_SECRET", "c29tZSBzZWNyZXQ=");
        assertDoesNotThrow(ChimeraService::main);
    }
}
JAVA

  # README
  cat > "${tmp}/README.md" <<'MD'
# Chimera – Google Cloud Event Publisher

## Purpose
Securely publish authenticated events to Google Cloud Pub/Sub.  
Each message contains a short-lived JWT signed with a per-tenant secret.

## Security
- JWT HS256 with base64-encoded 256-bit secret  
- Secret injected via `CHIMERA_JWT_SECRET` (never hard-coded)  
- Publisher runs with least-privilege service account (`roles/pubsub.publisher`)

## Build / Run
```bash
mvn clean package
export GCP_PROJECT_ID=your-project
export CHIMERA_JWT_SECRET=$(openssl rand -base64 32)
java -cp target/chimera-1.0.0.jar com.devinroyal.chimera.ChimeraService