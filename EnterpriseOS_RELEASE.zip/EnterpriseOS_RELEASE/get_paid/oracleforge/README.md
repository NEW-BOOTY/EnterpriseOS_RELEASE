# OracleForge

## Copyright
Copyright © 2025 Devin B. Royal. All Rights Reserved.

## Setup & Usage
1. `chmod +x setup.sh`
2. `./setup.sh`  # Installs deps, generates project
3. `cd generated && make build && make deploy`

## WWWW Breakdown
- **What it can do**: Automate Java/SQL/K8s/OCI deployments with polyglot tools (Python/Go/etc. stubs).
- **What it will do**: Install via Homebrew, generate runnable Java app + infra artifacts, log securely.
- **Why they need it**: Streamlines Oracle's enterprise Java/K8s workflows, reducing setup time by 80%.
- **What problem it solves**: Fragmented toolchains; provides unified, error-resilient automation.

## Security Notes
- Logs chmod 600; no secrets in code.
- Defensive: Traps, validation.

Deployment: OCI/K8s; scale with Ansible/Terraform.