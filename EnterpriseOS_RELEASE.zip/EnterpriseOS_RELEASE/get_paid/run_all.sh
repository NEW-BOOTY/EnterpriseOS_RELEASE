#!/bin/bash
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#

set -euo pipefail

# === CONFIG ===
BASE_DIR="all_frameworks"
MASTER_LOG="${BASE_DIR}/master_$(date +%Y%m%d_%H%M%S).log"
SUMMARY_MD="${BASE_DIR}/summary.md"
PROJECTS=(
    "oracleforge:OracleForge:java -cp generated/src HelloOracle"
    "azureweave:AzureWeave:dotnet run --project generated/src"
    "gobazelforge:GoBazelForge:go run generated/src/main.go"
    "hackpulse:HackPulse:hhvm generated/src/index.hack"
    "watsonweft:WatsonWeft:javac generated/src/HelloWatson.java && java -cp generated/src HelloWatson"
    "lambdaloom:LambdaLoom:cargo run --manifest-path generated/src/Cargo.toml"  # Rust Lambda sim
    "swiftsculpt:SwiftSculpt:swift generated/src/App.swift"
    "jaxnexus:JAXNexus:python generated/src/train.py"
)

# === VALIDATION ===
validate_env() {
    if [[ "$(uname -s)" != "Darwin" ]]; then echo "ERROR: macOS required." >&2; exit 1; fi
    if ! command -v brew &> /dev/null; then
        echo "Installing Homebrew..." >&2
        NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || exit 1
    fi
    if ! docker info &> /dev/null; then echo "WARNING: Docker not running. Starting..."; open -a Docker; sleep 30; fi
}

# === LOGGING ===
mkdir -p "${BASE_DIR}"
touch "${MASTER_LOG}"
chmod 600 "${MASTER_LOG}"
exec 1> >(tee -a "${MASTER_LOG}")
exec 2>&1
trap 'echo "FATAL at ${LINENO}" | tee -a "${MASTER_LOG}"; cleanup' ERR
cleanup() { echo "Cleanup..." >&2; exit 1; }

# === SUMMARY INIT ===
cat > "${SUMMARY_MD}" << 'EOF'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
# Framework Execution Summary

| Project | Status | Sample Output |
|---------|--------|---------------|
EOF

# === RUN ONE PROJECT ===
run_project() {
    local dir="$1" name="$2" run_cmd="$3" status="❌" output=""

    echo "=== EXECUTING: ${name} ===" >&2
    mkdir -p "${BASE_DIR}/${dir}"

    # Copy setup.sh (from your existing files or generate inline)
    if [[ ! -f "${dir}/setup.sh" ]]; then
        echo "ERROR: ${dir}/setup.sh missing. Ensure project files are in cwd." >&2
        status="❌ Missing setup.sh"
    else
        cd "${BASE_DIR}/${dir}"
        chmod +x setup.sh
        echo "Running setup.sh..." >&2
        ./setup.sh || { status="❌ Setup failed"; cd -; return; }

        cd generated
        echo "Building & running: ${run_cmd}" >&2
        if output=$(eval "${run_cmd}" 2>&1); then
            status="✅"
        else
            status="❌ Run failed"
        fi
        cd ../../..
    fi

    # Truncate long output
    local short_out=$(echo "$output" | head -n 5 | sed 's/[^a-zA-Z0-9 ]//g' | tr '\n' ' ' | cut -c1-80)
    [[ -z "$short_out" ]] && short_out="No output"

    echo "| ${name} | ${status} | ${short_out} |" >> "${SUMMARY_MD}"
    echo "${name}: ${status} -> ${short_out}" >&2
}

# === MAIN ===
main() {
    validate_env
    echo "Starting execution of all 8 frameworks..." >&2

    for proj in "${PROJECTS[@]}"; do
        IFS=":" read -r dir name cmd <<< "$proj"
        run_project "$dir" "$name" "$cmd"
    done

    echo "=== ALL DONE ===" >&2
    echo "Summary: ${SUMMARY_MD}"
    echo "Master Log: ${MASTER_LOG}"
    echo "Projects in: ${BASE_DIR}/"
    echo "To re-run: ./run_all.sh"
}

main "$@"
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#