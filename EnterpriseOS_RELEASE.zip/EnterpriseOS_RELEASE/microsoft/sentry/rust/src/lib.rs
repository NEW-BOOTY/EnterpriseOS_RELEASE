#[no_mangle]
pub extern "C" fn analyze_risk() -> i32 { 42 }
