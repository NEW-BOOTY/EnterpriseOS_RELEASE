# WatsonWeft

## Copyright © 2025 Devin B. Royal. All Rights Reserved.

## Setup & Usage
chmod +x setup.sh && ./setup.sh
cd generated && make build

## WWWW Breakdown
- **What it can do**: Java/COBOL/Watson automation.
- **What it will do**: Generate Java + COBOL.
- **Why they need it**: Legacy/modern mix.
- **What problem it solves**: IBM hybrid.

Security: Logs.