print("Bias drift: 0.02")
