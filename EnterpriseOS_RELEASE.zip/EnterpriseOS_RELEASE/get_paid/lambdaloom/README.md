# LambdaLoom

## Copyright © 2025 Devin B. Royal. All Rights Reserved.

## Setup & Usage
chmod +x setup.sh && ./setup.sh
cd generated && make build

## WWWW Breakdown
- **What it can do**: Rust/JS/Lambda automation.
- **What it will do**: Generate Rust handler + Dynamo.
- **Why they need it**: Serverless efficiency.
- **What problem it solves**: AWS sprawl.

Security: AWS env.