Technical Explanation
Installs AWSCLI/Rust, generates Rust Lambda, JS handler, Dynamo DDL, ECS JSON, AWS Terraform. Features: TypeScript stub. Error: Cargo check. Security: No keys.
(ZIP: lambdaloom.zip)