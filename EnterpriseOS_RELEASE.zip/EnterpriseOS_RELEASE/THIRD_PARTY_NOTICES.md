/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# Third-Party Notices

Enterprise-OS™ uses the following third-party components in the demo:

- **FastAPI** – Web framework for Python (License: MIT)
- **Uvicorn** – ASGI server (License: BSD-3-Clause)
- **Pydantic** – Data validation and settings management (License: MIT)
- **MinIO Python SDK** – S3-compatible client (License: Apache-2.0)
- **sentence-transformers** – Embedding models (License: Apache-2.0)
- **NumPy** – Numerical computing (License: BSD-3-Clause)

Each project’s full license text is available in its own repository. Where
required, license texts may be included inside the generated SBOM or within
vendor-specific documentation.

/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
