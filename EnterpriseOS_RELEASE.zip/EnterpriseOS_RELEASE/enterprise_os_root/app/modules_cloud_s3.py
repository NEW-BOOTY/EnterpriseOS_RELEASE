"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""

from __future__ import annotations

import os
import uuid
from typing import Any, Dict

from minio import Minio
from minio.error import S3Error

from .base_module import BaseModule
from .models import ModuleKind


class CloudS3Module(BaseModule):
    def __init__(self) -> None:
        super().__init__(
            name="cloud-s3",
            kind=ModuleKind.CLOUD,
            description="Minimal S3-compatible flow using MinIO: create bucket, upload object, return metadata.",
        )

    def _client(self) -> Minio:
        endpoint = os.getenv("MINIO_ENDPOINT", "localhost:9000")
        access_key = os.getenv("MINIO_ACCESS_KEY", "")
        secret_key = os.getenv("MINIO_SECRET_KEY", "")
        secure = os.getenv("MINIO_SECURE", "false").lower() == "true"

        if not access_key or not secret_key:
            raise RuntimeError("MINIO_ACCESS_KEY and MINIO_SECRET_KEY must be set in the environment.")

        return Minio(endpoint, access_key=access_key, secret_key=secret_key, secure=secure)

    async def trigger(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        bucket = payload.get("bucket_name", "enterprise-os-demo")
        content = payload.get("content", "Enterprise-OS cloud demo object.")
        object_name = payload.get("object_name", f"demo-{uuid.uuid4().hex}.txt")

        try:
            client = self._client()

            if not client.bucket_exists(bucket):
                client.make_bucket(bucket)

            from io import BytesIO

            data = BytesIO(content.encode("utf-8"))
            result = client.put_object(bucket, object_name, data, length=len(content.encode("utf-8")))

            stat = client.stat_object(bucket, object_name)
            meta = {
                "bucket": bucket,
                "object": object_name,
                "etag": result.etag,
                "size": stat.size,
                "content_type": stat.content_type,
            }
            self._mark_success(metrics=meta)
            return meta
        except Exception as exc:  # noqa: BLE001
            self._mark_error(str(exc))
            raise

    async def health(self) -> Dict[str, Any]:
        try:
            client = self._client()
            _ = list(client.list_buckets())
            self._mark_success(metrics={"health": "ok"})
            return {"status": "ok"}
        except S3Error as exc:
            self._mark_error(str(exc))
            return {"status": "error", "error": str(exc)}
        except Exception as exc:  # noqa: BLE001
            self._mark_error(str(exc))
            return {"status": "error", "error": str(exc)}


"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""
