#!/bin/bash
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#

set -euo pipefail

validate_env() {
    if [[ "$(uname -s)" != "Darwin" ]]; then echo "ERROR: macOS." >&2; exit 1; fi
    if ! command -v brew &> /dev/null; then NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || exit 1; fi
}

LOG_DIR="logs"
mkdir -p "${LOG_DIR}"
LOG_FILE="${LOG_DIR}/setup_$(date +%Y%m%d_%H%M%S).log"
touch "${LOG_FILE}"
chmod 600 "${LOG_FILE}"
exec 1> >(tee -a "${LOG_FILE}")
exec 2>&1
trap 'echo "FATAL ${LINENO}" | tee -a "${LOG_FILE}"; cleanup' ERR
cleanup() { find "${LOG_DIR}" -name "*.tmp" -delete; exit 1; }

install_deps() {
    brew update || exit 1
    brew install --quiet go bazelisk python@3.12 java dart kubernetes-cli terraform ansible rust nodejs tensorflow || true
    go version &> /dev/null || exit 1
    bazel --version &> /dev/null || exit 1
}

generate_project() {
    PROJ_DIR="generated"
    mkdir -p "${PROJ_DIR}/src" "${PROJ_DIR}/ml" "${PROJ_DIR}/terraform" "${PROJ_DIR}/systemd"

    cat > "${PROJ_DIR}/src/main.go" << 'EOF'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
package main
import "fmt"
func main() { fmt.Println("Hello GoBazelForge") }
EOF

    cat > "${PROJ_DIR}/ml/model.py" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
import tensorflow as tf
print("TF model in GoBazelForge")
EOF

    cat > "${PROJ_DIR}/Dockerfile" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
FROM golang:1.23
COPY src/ /app/
RUN go build /app/main.go
CMD ["/app/main"]
EOF

    cat > "${PROJ_DIR}/k8s-deployment.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
apiVersion: apps/v1
kind: Deployment
metadata: { name: gobazel }
spec: { replicas: 1, template: { spec: { containers: [{ name: go, image: gobazel:latest }] } } }
EOF

    cat > "${PROJ_DIR}/Makefile" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
build: bazel build //src:main
deploy: kubectl apply -f k8s-deployment.yaml
EOF

    cat > "${PROJ_DIR}/ansible-playbook.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
---
- hosts: localhost
  tasks: [kubernetes.core.k8s: { state: present, src: k8s-deployment.yaml }]
EOF

    cat > "${PROJ_DIR}/terraform/main.tf" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
provider "google" {}
resource "google_container_cluster" "forge" { name = "gobazel" }
EOF

    cat > "${PROJ_DIR}/cron-job.conf" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
*/10 * * * * /app/main >> /var/log/gobazel.log 2>&1
EOF

    cat > "${PROJ_DIR}/systemd/gobazel.service" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
[Unit]
Description=GoBazelForge
[Service]
ExecStart=/app/main
Restart=always
[Install]
WantedBy=multi-user.target
EOF

    cat > "${PROJ_DIR}/cicd-pipeline.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
stages: [build: bazel build, deploy: make deploy]
EOF

    echo "Generated in ${PROJ_DIR}" >&2
}

main() { validate_env; install_deps; generate_project; echo "GoBazelForge deployed. Logs: ${LOG_FILE}" >&2; }

main "$@"
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#