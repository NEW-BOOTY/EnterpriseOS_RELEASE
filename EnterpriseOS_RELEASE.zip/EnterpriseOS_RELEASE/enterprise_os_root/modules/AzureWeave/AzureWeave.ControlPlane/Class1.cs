﻿namespace AzureWeave.ControlPlane;

public class Class1
{

}
