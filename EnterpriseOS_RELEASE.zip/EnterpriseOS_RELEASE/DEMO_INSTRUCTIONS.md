# DEMO VIDEO INSTRUCTIONS

1. Run the CLI demo entrypoint to simulate a provider deployment.
2. Capture the terminal output and logs.
3. Walk through website/, SBOM, and CHECKSUMS.sha256.
