# Microsoft Outreach

- **Developer Relations**: Microsoft Partner Finder[](https://partner.microsoft.com/en-us/partnership/find-a-partner); Jobs[](https://www.linkedin.com/jobs/microsoft-developer-relations-jobs).
- **Partnerships**: partner.microsoft.com .
- **Innovation Labs**: AI for Good[](https://aiforgood.itu.int/about-us/innovation-factory/).
- **CTO**: Kevin Scott LinkedIn[](https://www.linkedin.com/in/jkevinscott).
- **LinkedIn/AngelList**: Microsoft LinkedIn; AngelList .