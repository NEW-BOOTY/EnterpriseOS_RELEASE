/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# Enterprise-OS™ Demo Control Plane

Enterprise-OS™ is a unified control plane that orchestrates three core
capabilities:

1. **Cloud** – S3-compatible storage flow using MinIO.
2. **AI** – Local embedding-based similarity scoring using sentence-transformers.
3. **Compliance** – Static policy scanning for banned patterns and encryption flags.

This repository provides a **bootstrappable demo** that you can run locally
or via Docker/Kubernetes and then license and harden for enterprise use.

## High-Level Architecture (ASCII)

```text
 +-----------------------------+
 |      Enterprise-OS™         |
 |        Control Plane        |
 |        (FastAPI)            |
 +---------------+-------------+
                 |
     +-----------+-----------+
     |           |           |
     v           v           v
+----------+ +---------+ +-----------------+
| Cloud    | |   AI    | |  Compliance     |
| (MinIO)  | | (Embeds)| | (Policy Scan)   |
+----------+ +---------+ +-----------------+
One-Command Demo
git clone <your-repo-url> enterprise-os
cd enterprise-os
./enterprise_os_root.sh demo
The demo will:
Create a Python virtualenv.
Install dependencies.
Launch the FastAPI control plane on http://127.0.0.1:8080.
Run a full workflow:
S3 bucket + object on MinIO (if configured).
AI similarity between two sample texts.
Compliance scan of a sample config.
Print module statuses and the dashboard URL.
For more detailed setup instructions, see INSTALL.md and QUICKSTART.md.
/*
Copyright © 2025 Devin B. Royal.
All Rights Reserved.
*/

---

### 2. INSTALL.md

**File:** `./INSTALL.md`

```markdown
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# Installation Guide

## Prerequisites

Minimal system prerequisites:

- macOS or Linux
- `python3` (3.11 recommended)
- `pip3`
- `curl`

Optional:

- Docker + Docker Compose (for containerized demo)
- `syft` (for SBOM generation)
- `pre-commit` (for dev hygiene)

## Local Python Demo

```bash
git clone <your-repo-url> enterprise-os
cd enterprise-os
./enterprise_os_root.sh install
./enterprise_os_root.sh run
Then in another terminal:
./enterprise_os_root.sh status
curl http://127.0.0.1:8080/health
curl http://127.0.0.1:8080/demo/run -X POST \
  -H "Content-Type: application/json" \
  -d '{"text_a":"foo","text_b":"bar"}'
Docker Demo
Copy .env.example to .env and set MINIO_ROOT_USER and MINIO_ROOT_PASSWORD.
Build and run:
docker compose up --build
Control plane will be available at http://localhost:8080 and MinIO console
at http://localhost:9001.
Pre-Commit Hooks
For development:
pip install pre-commit
pre-commit install
/*
Copyright © 2025 Devin B. Royal.
All Rights Reserved.
*/

---

### 3. QUICKSTART.md

**File:** `./QUICKSTART.md`

```markdown
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# Quickstart

1. Clone the repo:
   ```bash
   git clone <your-repo-url> enterprise-os
   cd enterprise-os
Run the one-command demo:
./enterprise_os_root.sh demo
Open:
Health: http://127.0.0.1:8080/health
Docs: http://127.0.0.1:8080/docs
Dashboard: http://127.0.0.1:8080/dashboard
/*
Copyright © 2025 Devin B. Royal.
All Rights Reserved.
*/

---

### 4. Per-framework READMEs (cloud, AI, compliance)

**File:** `./enterprise_os_root/app/README.cloud.md`

```markdown
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# Cloud Module (MinIO S3 Demo)

## Overview

The `cloud-s3` module demonstrates a minimal S3-compatible flow using MinIO:

- Creates a bucket (if missing).
- Uploads a demo text object.
- Returns object metadata.

## API

Trigger via control plane:

```bash
curl -X POST http://127.0.0.1:8080/trigger \
  -H "Content-Type: application/json" \
  -d '{"module":"cloud-s3","payload":{"bucket_name":"enterprise-os-demo"}}'
Health:
curl http://127.0.0.1:8080/health/cloud-s3
/*
Copyright © 2025 Devin B. Royal.
All Rights Reserved.
*/

Similarly create `README.ai.md` and `README.compliance.md` describing their APIs (same pattern, shorter text).

---

### 5. Runbook

**File:** `./RUNBOOK.md`

```markdown
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# Enterprise-OS™ Runbook

## Start / Stop

### Local Python

```bash
./enterprise_os_root.sh run      # start control plane
./enterprise_os_root.sh status   # show health
./enterprise_os_root.sh clean    # stop and clean state
Docker
docker compose up --build   # start
docker compose down         # stop
Health Checks
Control plane health: GET /health
Module-specific health: GET /health/{module_name}
Logs
Orchestrator logs: enterprise_os_root/logs/enterprise_os_root_*.log
Control plane server logs: enterprise_os_root/logs/control_plane_uvicorn.log
MinIO Operations
Credentials: provided via environment or Kubernetes Secret.
Backup: snapshot minio-data volume (Docker) or underlying PV (Kubernetes).
Incident Response
Check RUNBOOK.md for start/stop and logs.
If control plane is unhealthy:
Restart via ./enterprise_os_root.sh clean && ./enterprise_os_root.sh run.
If MinIO issues occur:
Verify secrets and service reachability.
Check MinIO logs and console.
Rollback
Use container tags (e.g., enterprise-os/control-plane:0.1.0-demo) to roll
back to a previous version.
Keep SBOMs under sbom/ for each release to track dependencies.
/*
Copyright © 2025 Devin B. Royal.
All Rights Reserved.
*/

---

## H) CI/CD, tests, lint, artifacts

### 1. Basic tests

**File:** `./enterprise_os_root/tests/test_health.py`

```python
"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""

from fastapi.testclient import TestClient

from app.main import app


def test_health():
    client = TestClient(app)
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"


"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""