#!/bin/bash
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#

set -euo pipefail

validate_env() {
    if [[ "$(uname -s)" != "Darwin" ]]; then echo "ERROR: macOS required for Homebrew." >&2; exit 1; fi
    if ! command -v brew &> /dev/null; then
        echo "Installing Homebrew..." >&2
        NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || { echo "Homebrew install failed." >&2; exit 1; }
    fi
}

LOG_DIR="logs"
mkdir -p "${LOG_DIR}"
LOG_FILE="${LOG_DIR}/setup_$(date +%Y%m%d_%H%M%S).log"
touch "${LOG_FILE}"
chmod 600 "${LOG_FILE}"
exec 1> >(tee -a "${LOG_FILE}")
exec 2>&1
trap 'echo "FATAL ERROR at line ${LINENO}: ${BASH_COMMAND}" | tee -a "${LOG_FILE}"; cleanup' ERR
cleanup() {
    echo "Cleanup initiated..." >&2
    find "${LOG_DIR}" -name "*.tmp" -delete
    exit 1
}

install_deps() {
    echo "Installing dependencies via Homebrew..." >&2
    brew update || { echo "Brew update failed." >&2; exit 1; }
    brew install --quiet openjdk@17 docker kubectl terraform ansible python@3.12 go rust nodejs postgresql@14 || true
    java --version &> /dev/null || { echo "Java install failed." >&2; exit 1; }
    docker --version &> /dev/null || { echo "Docker install failed." >&2; exit 1; }
    kubectl version --client &> /dev/null || { echo "Kubectl install failed." >&2; exit 1; }
}

generate_project() {
    PROJ_DIR="generated"
    mkdir -p "${PROJ_DIR}/src" "${PROJ_DIR}/db" "${PROJ_DIR}/terraform" "${PROJ_DIR}/systemd"

    cat > "${PROJ_DIR}/src/HelloOracle.java" << 'EOF'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
import java.sql.*;

public class HelloOracle {
    public static void main(String[] args) {
        String url = System.getenv("ORACLE_JDBC_URL");
        if (url == null) { System.err.println("Missing ORACLE_JDBC_URL"); System.exit(1); }
        try (Connection conn = DriverManager.getConnection(url, "user", "pass");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT 'Hello OracleForge' FROM DUAL")) {
            if (rs.next()) System.out.println(rs.getString(1));
        } catch (SQLException e) { e.printStackTrace(); System.exit(1); }
    }
}
EOF

    cat > "${PROJ_DIR}/db/schema.sql" << 'EOF'
-- Copyright © 2025 Devin B. Royal. All Rights Reserved.
CREATE TABLE forge_log (id NUMBER, msg VARCHAR2(255));
INSERT INTO forge_log VALUES (1, 'OracleForge Deployed');
COMMIT;
EOF

    cat > "${PROJ_DIR}/Dockerfile" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
FROM openjdk:17
COPY src/HelloOracle.java /app/
RUN javac /app/HelloOracle.java
CMD ["java", "-cp", "/app", "HelloOracle"]
EOF

    cat > "${PROJ_DIR}/k8s-deployment.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
apiVersion: apps/v1
kind: Deployment
metadata: { name: oracleforge }
spec:
  replicas: 1
  template:
    spec:
      containers:
      - name: app
        image: oracleforge:latest
        env: [{ name: ORACLE_JDBC_URL, value: "jdbc:oracle:thin:@db:1521:XE" }]
EOF

    cat > "${PROJ_DIR}/Makefile" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
build: docker build -t oracleforge .
deploy: kubectl apply -f k8s-deployment.yaml
EOF

    cat > "${PROJ_DIR}/ansible-playbook.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
---
- hosts: localhost
  tasks:
  - kubernetes.core.k8s: { state: present, src: k8s-deployment.yaml }
EOF

    cat > "${PROJ_DIR}/terraform/main.tf" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
provider "oci" {}
resource "oci_containerengine_cluster" "forge" { name = "oracleforge" }
EOF

    cat > "${PROJ_DIR}/cron-job.conf" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
* * * * * docker run oracleforge:latest >> /var/log/oracleforge.log 2>&1
EOF

    cat > "${PROJ_DIR}/systemd/oracleforge.service" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
[Unit]
Description=OracleForge
[Service]
ExecStart=/usr/bin/docker run oracleforge:latest
Restart=always
[Install]
WantedBy=multi-user.target
EOF

    cat > "${PROJ_DIR}/cicd-pipeline.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
stages: [build: make build, deploy: ansible-playbook ansible-playbook.yaml]
EOF

    echo "Generated in ${PROJ_DIR}" >&2
}

main() { validate_env; install_deps; generate_project; echo "OracleForge deployed. Logs: ${LOG_FILE}" >&2; }

main "$@"
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#