#!/bin/bash
set -euo pipefail
LOG_DIR="logs"; mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/setup_$(date +%Y%m%d_%H%M%S).log"
touch "$LOG_FILE"; chmod 600 "$LOG_FILE"
exec 1>> "$LOG_FILE" 2>&1

echo "Installing: python@3.12"
brew update || true
brew install --quiet python@3.12 || true

PROJ="generated"
mkdir -p "$PROJ/src" "$PROJ/db" "$PROJ/terraform" "$PROJ/systemd"
cat > "$PROJ/src/train.py" << 'PY'
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
print("Hello JAXNexus")
PY
echo "Generated in $PROJ"
