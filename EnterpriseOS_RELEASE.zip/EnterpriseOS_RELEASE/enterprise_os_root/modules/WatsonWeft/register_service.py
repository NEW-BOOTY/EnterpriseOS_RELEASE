#!/usr/bin/env python3
import requests
import json
import time

JENKINS_URL = "http://localhost:8080/generic-webhook-trigger/invoke"
JENKINS_TOKEN = "ENTERPRISE-OS-DEV-KEY"

payload = {
    "service": "WatsonWeft",
    "status": "OK",
    "timestamp": int(time.time())
}

headers = {
    "Content-Type": "application/json",
    "X-Jenkins-Token": JENKINS_TOKEN
}

print("[WatsonWeft] Sending registration to Jenkins:", JENKINS_URL)

try:
    r = requests.post(JENKINS_URL, data=json.dumps(payload), headers=headers, timeout=5)
    r.raise_for_status()
    print("[WatsonWeft] Jenkins webhook OK:", r.status_code)
except Exception as e:
    print("[WatsonWeft] Registration failed:", str(e))
