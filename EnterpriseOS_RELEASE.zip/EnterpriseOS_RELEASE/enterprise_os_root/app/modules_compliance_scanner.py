"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List

from .base_module import BaseModule
from .models import ModuleKind


BANNED_PATTERNS = [
    (re.compile(r"password\s*:"), "Plaintext password field detected."),
    (re.compile(r"access[_-]?key\s*:"), "Access key field detected; ensure secure storage."),
    (re.compile(r"secret\s*[:=]"), "Secret value detected; avoid plaintext secrets."),
    (re.compile(r"encryption\s*:\s*false", re.IGNORECASE), "Encryption disabled; set encryption: true."),
]


class ComplianceScannerModule(BaseModule):
    def __init__(self) -> None:
        super().__init__(
            name="compliance-scanner",
            kind=ModuleKind.COMPLIANCE,
            description="Static policy scanner for banned patterns and encryption flags.",
        )

    async def trigger(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        config_text = payload.get("config_text")
        if not config_text:
            raise ValueError("Payload must contain 'config_text'.")

        issues: List[Dict[str, Any]] = []
        for pattern, message in BANNED_PATTERNS:
            for m in pattern.finditer(config_text):
                issues.append(
                    {
                        "offset": m.start(),
                        "pattern": pattern.pattern,
                        "message": message,
                    }
                )

        compliance_passed = len(issues) == 0
        metrics = {"compliance_passed": compliance_passed, "issue_count": len(issues)}
        self._mark_success(metrics=metrics)
        return {"passed": compliance_passed, "issues": issues}

    async def health(self) -> Dict[str, Any]:
        self._mark_success(metrics={"health": "ok"})
        return {"status": "ok"}


"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""
