/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

package com.enterpriseos;

import java.util.Random;

/**
 * Entry point for Sentry security module.
 * Executes a simulated risk-score event and publishes it to the audit bus.
 */
public class SentryMain {

    public static void main(String[] args) {
        System.out.println("=== ENTERPRISE-OS SENTRY MODULE ===");

        try {
            SecurityBusClient client = new SecurityBusClient();
            String instanceId = "SENTRY-JAVA-001";

            double riskScore = 20 + (new Random().nextDouble() * 80);

            boolean ok = client.publishRiskScore(instanceId, riskScore);

            if (ok) {
                System.out.println("[SENTRY] Risk score published successfully.");
            } else {
                System.err.println("[SENTRY] Failed to publish risk score.");
            }

        } catch (Exception e) {
            System.err.println("[SENTRY] CRITICAL ERROR: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("=== SENTRY MODULE COMPLETE ===");
    }
}

/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
