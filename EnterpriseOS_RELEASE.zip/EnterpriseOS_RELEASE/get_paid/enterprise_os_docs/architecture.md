# Enterprise OS Architecture (SAFE MODE)

## Layers

1. Unified Framework Manager
2. Project Trees per Framework (chimera, sentry, aegis, veritas, synergy, clarity, orchard, connect)
3. Local Audit Engine (SBOM/MBOM/secrets/config checks)
4. v2.0 Architecture:
   - Job Runner (local queue)
   - Plugin Marketplace (extensible)
   - Node-Graph Orchestrator (simple DAG)
5. GUI Dashboard (React + FastAPI)
6. Daemon & Installer Templates (launchd/systemd/.pkg skeleton)

## SAFE MODE Guarantees

- No direct cloud enumeration is performed.
- No system daemons or services are enabled automatically.
- No pkg installers are built or installed.
- No credentials are stored by the script; it only reads env vars.
