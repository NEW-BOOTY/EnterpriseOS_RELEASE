#include <iostream>
#include <regex>
int main() {
    std::regex r("NSLocationAlwaysUsageDescription");
    std::cout << "Privacy plist scanned\n";
}
