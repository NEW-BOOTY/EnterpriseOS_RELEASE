print('{"report":"GDPR compliance","deletions":3}')
