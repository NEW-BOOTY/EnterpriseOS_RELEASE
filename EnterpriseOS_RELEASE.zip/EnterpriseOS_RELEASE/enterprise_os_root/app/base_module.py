"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, Optional

from .models import ModuleKind, ModuleRegistration, ModuleStatus


class BaseModule(ABC):
    def __init__(self, name: str, kind: ModuleKind, description: str, version: str = "0.1.0-demo") -> None:
        self._name = name
        self._kind = kind
        self._description = description
        self._version = version
        self._last_run_at: Optional[datetime] = None
        self._last_error: Optional[str] = None
        self._metrics: Dict[str, Any] = {}

    @property
    def name(self) -> str:
        return self._name

    @property
    def kind(self) -> ModuleKind:
        return self._kind

    def registration(self) -> ModuleRegistration:
        return ModuleRegistration(
            name=self._name,
            kind=self._kind,
            version=self._version,
            description=self._description,
            enabled=True,
        )

    def status(self) -> ModuleStatus:
        return ModuleStatus(
            name=self._name,
            kind=self._kind,
            healthy=self._last_error is None,
            last_run_at=self._last_run_at,
            last_error=self._last_error,
            metrics=self._metrics,
        )

    @abstractmethod
    async def trigger(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        ...

    @abstractmethod
    async def health(self) -> Dict[str, Any]:
        ...

    def _mark_success(self, metrics: Dict[str, Any] | None = None) -> None:
        self._last_run_at = datetime.utcnow()
        self._last_error = None
        self._metrics = metrics or {}

    def _mark_error(self, error: str, metrics: Dict[str, Any] | None = None) -> None:
        self._last_run_at = datetime.utcnow()
        self._last_error = error
        self._metrics = metrics or {}

"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""
