# TRADEMARKS

Enterprise-OS™ and related marks are the property of Devin B. Royal.
Other names and logos may be trademarks of their respective owners.
