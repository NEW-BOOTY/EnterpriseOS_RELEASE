const { useState, useEffect } = React;

function App() {
  const [status, setStatus] = useState("Idle");
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const wsUrl = (window.location.protocol === "https:" ? "wss://" : "ws://") +
                  window.location.host + "/ws";
    const ws = new WebSocket(wsUrl);
    ws.onmessage = (event) => {
      setLogs((prev) => [...prev, event.data]);
    };
    ws.onopen = () => setStatus("Connected");
    ws.onclose = () => setStatus("Disconnected");
    return () => ws.close();
  }, []);

  function runEverything() {
    fetch("/api/run-everything", { method: "POST" })
      .then(() => setStatus("Running everything..."))
      .catch(() => setStatus("Error triggering run"));
  }

  return React.createElement(
    "div",
    { style: { padding: "1.5rem" } },
    React.createElement("h1", null, "Enterprise OS Dashboard (SAFE MODE)"),
    React.createElement("p", null, "Status: ", status),
    React.createElement("button", { onClick: runEverything, style:{padding:"0.5rem 1rem",marginTop:"0.5rem"} }, "Run Everything"),
    React.createElement(
      "pre",
      {
        style: {
          marginTop: "1rem",
          maxHeight: "60vh",
          overflow: "auto",
          background: "#0b1020",
          padding: "1rem",
          borderRadius: "0.5rem"
        }
      },
      logs.join("\n")
    )
  );
}

ReactDOM.render(React.createElement(App), document.getElementById("root"));
