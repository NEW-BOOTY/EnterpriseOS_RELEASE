# Enterprise OS Plugin Marketplace (SAFE MODE)

Drop Python or shell plugins here to extend Enterprise OS.

Suggested structure:
- plugin_x/
  - plugin_x.yaml    # metadata
  - plugin_x.py      # implementation
