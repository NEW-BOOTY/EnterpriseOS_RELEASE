/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */

# Changelog

## [0.1.0-demo] - 2025-11-21

- Added canonical orchestrator `enterprise_os_root.sh` with `demo/install/run/clean/status`.
- Implemented FastAPI control plane with built-in cloud, AI, and compliance modules.
- Added Dockerfile and docker-compose for local demo, plus Kubernetes manifests.
- Introduced SBOM generation script and security/compliance docs.
- Wired CI pipeline (Jenkins) for lint, test, build, and SBOM.

 /*
  * Copyright © 2025 Devin B. Royal.
  * All Rights Reserved.
  */
