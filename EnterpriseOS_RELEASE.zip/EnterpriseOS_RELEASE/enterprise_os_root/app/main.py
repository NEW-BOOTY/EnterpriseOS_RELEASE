"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""

from __future__ import annotations

import logging
import os
import time
import uuid
from typing import Dict, List

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, HTMLResponse
from pydantic import ValidationError
from fastapi.middleware.cors import CORSMiddleware

from .models import (
    ModuleRegistration,
    TriggerRequest,
    ModuleStatus,
    DemoRunRequest,
    DemoRunResult,
)
from .base_module import BaseModule
from .modules_cloud_s3 import CloudS3Module
from .modules_ai_embeddings import AIEmbeddingModule
from .modules_compliance_scanner import ComplianceScannerModule

logger = logging.getLogger("enterprise_os.control_plane")
logging.basicConfig(
    format="%(asctime)s level=%(levelname)s msg=\"%(message)s\"",
    level=logging.INFO,
)

app = FastAPI(
    title="Enterprise-OS Control Plane",
    description="Control plane API for cloud, AI, and compliance modules.",
    version="0.1.0-demo",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # demo only; lock down in production
    allow_methods=["*"],
    allow_headers=["*"],
)

MODULES: Dict[str, BaseModule] = {}


def _register_builtin_modules() -> None:
    builtin = [
        CloudS3Module(),
        AIEmbeddingModule(),
        ComplianceScannerModule(),
    ]
    for m in builtin:
        MODULES[m.name] = m
        logger.info("module_registered name=%s kind=%s", m.name, m.kind.value)


@app.on_event("startup")
async def on_startup() -> None:
    logger.info("startup_event environment=%s", os.getenv("ENTERPRISE_OS_ENVIRONMENT", "unknown"))
    _register_builtin_modules()


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    start = time.time()
    correlation_id = request.headers.get("X-Correlation-ID") or str(uuid.uuid4())
    try:
        response = await call_next(request)
    except Exception as exc:  # noqa: BLE001
        logger.exception("unhandled_exception path=%s correlation_id=%s", request.url.path, correlation_id)
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error", "correlation_id": correlation_id},
        )
    duration = time.time() - start
    logger.info(
        "http_request method=%s path=%s status=%s duration_ms=%.2f correlation_id=%s",
        request.method,
        request.url.path,
        response.status_code,
        duration * 1000,
        correlation_id,
    )
    response.headers["X-Correlation-ID"] = correlation_id
    return response


@app.get("/health")
async def health() -> Dict[str, str]:
    return {"status": "ok", "version": app.version}


@app.get("/modules", response_model=List[ModuleRegistration])
async def list_modules() -> List[ModuleRegistration]:
    return [m.registration() for m in MODULES.values()]


@app.post("/register", response_model=ModuleRegistration)
async def register_module(reg: ModuleRegistration) -> ModuleRegistration:
    # For demo, this only stores metadata; builtins are already loaded.
    logger.info("register_module name=%s kind=%s", reg.name, reg.kind.value)
    return reg


@app.post("/trigger")
async def trigger(req: TriggerRequest):
    module = MODULES.get(req.module)
    if module is None:
        raise HTTPException(status_code=404, detail=f"Unknown module '{req.module}'")
    try:
        result = await module.trigger(req.payload)
        return {"module": req.module, "result": result}
    except ValidationError as ve:
        logger.warning("trigger_validation_error module=%s error=%s", req.module, ve)
        raise HTTPException(status_code=400, detail=str(ve)) from ve
    except Exception as exc:  # noqa: BLE001
        logger.exception("trigger_error module=%s", req.module)
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/status", response_model=List[ModuleStatus])
async def status() -> List[ModuleStatus]:
    return [m.status() for m in MODULES.values()]


@app.get("/health/{module_name}")
async def module_health(module_name: str):
    module = MODULES.get(module_name)
    if module is None:
        raise HTTPException(status_code=404, detail=f"Unknown module '{module_name}'")
    return await module.health()


@app.post("/demo/run", response_model=DemoRunResult)
async def run_demo(req: DemoRunRequest) -> DemoRunResult:
    # 1) Cloud: put object
    cloud_mod = MODULES["cloud-s3"]
    cloud_result = await cloud_mod.trigger(
        {"content": req.text_a, "object_name": "demo-object.txt", "bucket_name": "enterprise-os-demo"}
    )

    # 2) AI: similarity between strings
    ai_mod = MODULES["ai-embeddings"]
    ai_result = await ai_mod.trigger({"text_a": req.text_a, "text_b": req.text_b})

    # 3) Compliance: scan a sample config
    config_text = """
    api_url: https://example.internal
    encryption: false
    password: supersecret
    """
    comp_mod = MODULES["compliance-scanner"]
    comp_result = await comp_mod.trigger({"config_text": config_text})

    return DemoRunResult(
        s3_bucket=cloud_result["bucket"],
        s3_object=cloud_result["object"],
        similarity=ai_result["similarity"],
        compliance_passed=comp_result["passed"],
        compliance_issues=comp_result["issues"],
    )


@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard() -> str:
    # Minimal HTML dashboard; you can replace with full frontend later.
    statuses = [m.status() for m in MODULES.values()]
    rows = "".join(
        f"<tr><td>{s.name}</td><td>{s.kind.value}</td>"
        f"<td>{'OK' if s.healthy else 'ERROR'}</td><td>{s.last_run_at}</td><td>{s.last_error or ''}</td></tr>"
        for s in statuses
    )
    html = f"""
    <html>
      <head>
        <title>Enterprise-OS Dashboard</title>
        <style>
          body {{ font-family: system-ui, sans-serif; background:#111; color:#eee; }}
          table {{ border-collapse: collapse; width: 100%; }}
          th, td {{ border: 1px solid #444; padding: 8px; }}
          th {{ background:#222; }}
        </style>
      </head>
      <body>
        <h1>Enterprise-OS Demo Dashboard</h1>
        <p>Version: {app.version}</p>
        <table>
          <tr><th>Name</th><th>Kind</th><th>Healthy</th><th>Last Run</th><th>Last Error</th></tr>
          {rows}
        </table>
        <p>OpenAPI docs: <a style="color:#6cf;" href="/docs">/docs</a></p>
      </body>
    </html>
    """
    return html


"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""
