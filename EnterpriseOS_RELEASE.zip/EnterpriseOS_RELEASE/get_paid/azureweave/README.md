# AzureWeave

Copyright © 2025 Devin B. Royal. All Rights Reserved.

## Setup & Usage
1. `chmod +x setup.sh`
2. `./setup.sh`
3. `cd generated && make build`

## WWWW
- **What it can do**: Weave C#/.NET/Azure/PowerShell automations.
- **What it will do**: Install deps, generate C#/PS/Docker/Azure YAML.
- **Why they need it**: Unifies Microsoft stack for faster GitHub Actions.
- **What it solves**: Tool fragmentation in Azure devops.

Security: Secure logs, input validation.