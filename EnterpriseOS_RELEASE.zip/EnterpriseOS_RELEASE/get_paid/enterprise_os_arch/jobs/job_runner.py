#!/usr/bin/env python3
"""
SAFE-MODE Job Runner for Enterprise OS.

This is a simple local job queue + worker loop.
You can extend it to talk to Redis, RabbitMQ, or cloud queues.
"""

import queue
import threading
import time

JOB_QUEUE = queue.Queue()

def worker():
    while True:
        job = JOB_QUEUE.get()
        if job is None:
            break
        print(f"[JOB-RUNNER] Executing job: {job}")
        time.sleep(0.5)
        JOB_QUEUE.task_done()

def submit(job: str):
    JOB_QUEUE.put(job)

def main():
    t = threading.Thread(target=worker, daemon=True)
    t.start()
    for i in range(5):
        submit(f"demo-job-{i}")
    JOB_QUEUE.join()
    JOB_QUEUE.put(None)
    t.join()

if __name__ == "__main__":
    main()
