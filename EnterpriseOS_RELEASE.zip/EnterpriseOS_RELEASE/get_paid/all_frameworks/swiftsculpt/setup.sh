#!/bin/bash
set -euo pipefail
LOG_DIR="logs"; mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/setup_$(date +%Y%m%d_%H%M%S).log"
touch "$LOG_FILE"; chmod 600 "$LOG_FILE"
exec 1>> "$LOG_FILE" 2>&1

echo "Installing: swift"
brew update || true
brew install --quiet swift || true

PROJ="generated"
mkdir -p "$PROJ/src" "$PROJ/db" "$PROJ/terraform" "$PROJ/systemd"
cat > "$PROJ/src/App.swift" << 'SWIFT'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
print("Hello SwiftSculpt")
SWIFT
echo "Generated in $PROJ"
