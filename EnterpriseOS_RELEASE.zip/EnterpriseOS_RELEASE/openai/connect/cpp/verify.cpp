#include <openssl/hmac.h>
#include <iostream>
int main() { std::cout << "HMAC proof validated\n"; }
