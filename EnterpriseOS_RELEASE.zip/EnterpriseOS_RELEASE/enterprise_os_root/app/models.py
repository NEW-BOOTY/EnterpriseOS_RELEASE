"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""

from enum import Enum
from typing import Any, Dict, Optional, List
from datetime import datetime

from pydantic import BaseModel, Field


class ModuleKind(str, Enum):
    CLOUD = "cloud"
    AI = "ai"
    COMPLIANCE = "compliance"


class ModuleRegistration(BaseModel):
    name: str = Field(..., description="Unique module name")
    kind: ModuleKind
    version: str = "0.1.0-demo"
    description: str = ""
    enabled: bool = True


class TriggerRequest(BaseModel):
    module: str
    payload: Dict[str, Any] = Field(default_factory=dict)


class ModuleStatus(BaseModel):
    name: str
    kind: ModuleKind
    healthy: bool
    last_run_at: Optional[datetime] = None
    last_error: Optional[str] = None
    metrics: Dict[str, Any] = Field(default_factory=dict)


class DemoRunRequest(BaseModel):
    text_a: str
    text_b: str


class DemoRunResult(BaseModel):
    s3_bucket: str
    s3_object: str
    similarity: float
    compliance_passed: bool
    compliance_issues: List[Dict[str, Any]] = Field(default_factory=list)


"""
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
"""
