#!/usr/bin/env bash
#
# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
#
# ENTERPRISE-OS™ canonical orchestrator
# One-command path:
#   git clone ... && cd ... && ./enterprise_os_root.sh demo
#
# Subcommands:
#   demo   - full demo bootstrap + health checks
#   install - create venv, install Python deps
#   run    - start control plane in background
#   clean  - stop services, remove temp state
#   status - show control plane and module health

set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${SCRIPT_DIR}"
LOG_DIR="${PROJECT_ROOT}/logs"
STATE_DIR="${PROJECT_ROOT}/.state"
VENV_DIR="${PROJECT_ROOT}/.venv"
PYTHON="${VENV_DIR}/bin/python"
PIP="${VENV_DIR}/bin/pip"
CONTROL_PLANE_PORT="${ENTERPRISE_OS_PORT:-8080}"
CONTROL_PLANE_HOST="${ENTERPRISE_OS_HOST:-127.0.0.1}"
CONTROL_PLANE_PID_FILE="${STATE_DIR}/control_plane.pid"
LOG_FILE="${LOG_DIR}/enterprise_os_root_$(date -u +%Y%m%dT%H%M%SZ).log"

mkdir -p "${LOG_DIR}" "${STATE_DIR}"

log() {
  local level="$1"; shift
  local msg="$*"
  local ts
  ts="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "${ts} level=${level} msg=\"${msg}\"" | tee -a "${LOG_FILE}" >&2
}

die() {
  log "ERROR" "$*"
  exit 1
}

check_cmd() {
  local cmd="$1"
  command -v "${cmd}" >/dev/null 2>&1 || die "Missing required command: ${cmd}"
}

ensure_prereqs() {
  log "INFO" "Checking prerequisites..."
  check_cmd python3
  check_cmd pip3
  check_cmd curl
  log "INFO" "Prerequisites OK."
}

create_venv() {
  if [[ -d "${VENV_DIR}" ]]; then
    log "INFO" "Virtualenv already exists at ${VENV_DIR}"
    return 0
  fi
  log "INFO" "Creating virtualenv at ${VENV_DIR}"
  python3 -m venv "${VENV_DIR}" || die "Failed to create venv"
}

install_deps() {
  log "INFO" "Installing Python dependencies..."
  if [[ ! -x "${PIP}" ]]; then
    die "pip not found in venv (${PIP})"
  fi
  "${PIP}" install --upgrade pip wheel
  "${PIP}" install -r "${PROJECT_ROOT}/requirements.txt"
  log "INFO" "Python dependencies installed."
}

start_control_plane() {
  if [[ -f "${CONTROL_PLANE_PID_FILE}" ]]; then
    if kill -0 "$(cat "${CONTROL_PLANE_PID_FILE}")" >/dev/null 2>&1; then
      log "INFO" "Control plane already running (PID=$(cat "${CONTROL_PLANE_PID_FILE}"))"
      return 0
    else
      log "WARN" "Stale PID file found; cleaning it."
      rm -f "${CONTROL_PLANE_PID_FILE}"
    fi
  fi

  log "INFO" "Starting control plane on ${CONTROL_PLANE_HOST}:${CONTROL_PLANE_PORT}"

  ENTERPRISE_OS_ENVIRONMENT="demo" \
  ENTERPRISE_OS_PORT="${CONTROL_PLANE_PORT}" \
  ENTERPRISE_OS_HOST="${CONTROL_PLANE_HOST}" \
  "${PYTHON}" -m uvicorn app.main:app \
    --host "${CONTROL_PLANE_HOST}" \
    --port "${CONTROL_PLANE_PORT}" \
    --log-level info \
    >> "${LOG_DIR}/control_plane_uvicorn.log" 2>&1 &

  local pid=$!
  echo "${pid}" > "${CONTROL_PLANE_PID_FILE}"
  log "INFO" "Control plane started with PID=${pid}"

  # Wait for health
  local tries=30
  local url="http://${CONTROL_PLANE_HOST}:${CONTROL_PLANE_PORT}/health"
  while (( tries > 0 )); do
    if curl -sf "${url}" >/dev/null 2>&1; then
      log "INFO" "Control plane health OK at ${url}"
      return 0
    fi
    sleep 1
    ((tries--))
  done

  die "Control plane did not become healthy at ${url}"
}

stop_control_plane() {
  if [[ ! -f "${CONTROL_PLANE_PID_FILE}" ]]; then
    log "INFO" "No control plane PID file; nothing to stop."
    return 0
  fi
  local pid
  pid="$(cat "${CONTROL_PLANE_PID_FILE}")"
  if kill -0 "${pid}" >/dev/null 2>&1; then
    log "INFO" "Stopping control plane PID=${pid}"
    kill "${pid}" || true
  else
    log "WARN" "PID ${pid} not running."
  fi
  rm -f "${CONTROL_PLANE_PID_FILE}"
}

demo_workflow() {
  local base="http://${CONTROL_PLANE_HOST}:${CONTROL_PLANE_PORT}"
  log "INFO" "Triggering demo workflow via control plane..."

  log "INFO" "Listing modules..."
  curl -sSf "${base}/modules" | tee -a "${LOG_FILE}" || die "Failed to list modules"

  log "INFO" "Running end-to-end demo..."
  curl -sSf -X POST "${base}/demo/run" \
    -H "Content-Type: application/json" \
    -d '{"text_a": "Enterprise OS is running.", "text_b": "Enterprise OS control plane is healthy."}' \
    | tee -a "${LOG_FILE}" || die "Demo workflow failed"

  log "INFO" "Fetching module statuses..."
  curl -sSf "${base}/status" | tee -a "${LOG_FILE}" || die "Failed to fetch status"

  log "INFO" "Demo workflow complete."
  log "INFO" "OpenAPI docs: ${base}/docs"
  log "INFO" "Dashboard:     ${base}/dashboard"
}

cmd_install() {
  ensure_prereqs
  create_venv
  install_deps
}

cmd_run() {
  ensure_prereqs
  create_venv
  install_deps
  start_control_plane
}

cmd_clean() {
  log "INFO" "Cleaning state..."
  stop_control_plane
  rm -rf "${STATE_DIR}"/*
  log "INFO" "Clean complete."
}

cmd_status() {
  local base="http://${CONTROL_PLANE_HOST}:${CONTROL_PLANE_PORT}"
  if [[ -f "${CONTROL_PLANE_PID_FILE}" ]] && kill -0 "$(cat "${CONTROL_PLANE_PID_FILE}")" >/dev/null 2>&1; then
    log "INFO" "Control plane running (PID=$(cat "${CONTROL_PLANE_PID_FILE}"))"
  else
    log "INFO" "Control plane not running."
  fi

  if curl -sf "${base}/health" >/dev/null 2>&1; then
    log "INFO" "Control plane /health OK at ${base}/health"
  else
    log "WARN" "Control plane /health not reachable at ${base}/health"
  fi
}

cmd_demo() {
  cmd_run
  demo_workflow
}

usage() {
  cat <<EOF
Usage: $(basename "$0") <command>

Commands:
  demo     Bootstrap and run full demo (install + run + workflow)
  install  Create virtualenv and install dependencies
  run      Start control plane in background
  clean    Stop services, wipe transient state
  status   Show control plane and module health
  help     Show this message
EOF
}

main() {
  local cmd="${1:-help}"
  case "${cmd}" in
    demo)    cmd_demo ;;
    install) cmd_install ;;
    run)     cmd_run ;;
    clean)   cmd_clean ;;
    status)  cmd_status ;;
    help|*)  usage ;;
  esac
}

main "$@"

# /*
#  * Copyright © 2025 Devin B. Royal.
#  * All Rights Reserved.
#  */
