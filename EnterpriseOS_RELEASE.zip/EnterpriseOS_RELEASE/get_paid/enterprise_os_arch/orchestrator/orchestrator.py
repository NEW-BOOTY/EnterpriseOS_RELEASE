#!/usr/bin/env python3
"""
SAFE-MODE Node Graph Orchestrator.

Defines a simple DAG of phases:
  bootstrap -> audits -> gui -> docs

You can extend this to store node graphs on disk or in a DB.
"""

from collections import defaultdict, deque

GRAPH = defaultdict(list)
GRAPH["bootstrap"].append("audits")
GRAPH["audits"].append("gui")
GRAPH["gui"].append("docs")

def topo_sort(graph, start):
    visited = set()
    order = []

    def dfs(node):
        if node in visited:
            return
        visited.add(node)
        for nxt in graph[node]:
            dfs(nxt)
        order.append(node)

    dfs(start)
    order.reverse()
    return order

def main():
    order = topo_sort(GRAPH, "bootstrap")
    print("[ORCHESTRATOR] Execution order:", " -> ".join(order))

if __name__ == "__main__":
    main()
