SELECT 'Oracle License OK' FROM DUAL;
