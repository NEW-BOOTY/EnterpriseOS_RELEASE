#!/usr/bin/env bash
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#

set -euo pipefail

echo "=== ENTERPRISE-OS™ MODULE RUNNER ==="
echo "[INFO] Working directory: $(pwd)"
echo

ROOT_DIR="$(pwd)"

sep() {
  echo "------------------------------------------------------------------"
}

# ============================
#  SENTRY (Java)
# ============================
run_sentry() {
  if [[ -d "Sentry/src/main/java/com/enterpriseos" ]]; then
    sep
    echo "[SENTRY] Building and running Sentry (Java)..."
    cd Sentry
    rm -rf out
    mkdir -p out
    javac -d out $(find src/main/java -name "*.java")
    java -cp out com.enterpriseos.SentryMain || echo "[SENTRY] WARNING: runtime error"
    cd ..
  fi
}

# ============================
#  LAMBDALOOM (Rust)
# ============================
run_lambdaloom() {
  if [[ -f "Lambdaloom/Cargo.toml" ]]; then
    sep
    echo "[LAMBDA] Building and running Lambdaloom (Rust)..."
    cd Lambdaloom
    cargo build
    cargo run || echo "[LAMBDA] WARNING: runtime error"
    cd ..
  fi
}

# ============================
#  HACKPULSE (Go)
# ============================
run_hackpulse() {
  if [[ -f "HackPulse/main.go" ]]; then
    sep
    echo "[HACKPULSE] Building and running HackPulse (Go)..."
    cd HackPulse
    go build -o hackpulse-agent
    ./hackpulse-agent || echo "[HACKPULSE] WARNING: runtime error"
    cd ..
  fi
}

# ============================
#  AZUREWEAVE (C#)
# ============================
run_azureweave() {
  if [[ -d "AzureWeave/AzureWeave.ControlPlane" ]]; then
    sep
    echo "[AZUREWEAVE] Building AzureWeave.ControlPlane (.NET)..."
    cd AzureWeave/AzureWeave.ControlPlane
    dotnet build || echo "[AZUREWEAVE] WARNING: build error"
    cd ../..
  fi
}

# ============================
#  WATSONWEFT (Python)
# ============================
run_watsonweft() {
  if [[ -f "WatsonWeft/register_service.py" ]]; then
    sep
    echo "[WATSONWEFT] Registering WatsonWeft with control plane..."
    cd WatsonWeft

    if [[ -f "../../.venv/bin/activate" ]]; then
      # shellcheck disable=SC1091
      source ../../.venv/bin/activate
      python register_service.py || echo "[WATSONWEFT] WARNING: registration failed"
      deactivate || true
    else
      echo "[WATSONWEFT] WARNING: .venv not found"
    fi

    cd ..
  fi
}

# ============================
# RUN EVERYTHING
# ============================

run_sentry
run_lambdaloom
run_hackpulse
run_azureweave
run_watsonweft

sep
echo "=== ALL MODULES FINISHED ==="

#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#
