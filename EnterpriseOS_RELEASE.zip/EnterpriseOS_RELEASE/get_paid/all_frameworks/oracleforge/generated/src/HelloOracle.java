/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
public class HelloOracle {
    public static void main(String[] args) {
        System.out.println("Hello OracleForge");
    }
}
