# INSTALLATION

## Prerequisites
- Bash (4.x or newer recommended)
- Python 3.x
- Git

## Quick Start
1. Extract this archive.
2. From the project root, review LICENSE.txt and SECURITY.md.
3. Integrate with your CI/CD pipeline and secret management (Vault, KMS, etc.).
